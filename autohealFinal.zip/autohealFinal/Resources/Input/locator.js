function getPosition(element) {  
    if (element===document.body) return '//' ;
  
    var ix= 0;
    var siblings= element.parentNode.childNodes; 
    for (var i= 0; i<siblings.length; i++) {
        var sibling= siblings[i]; 
        if (sibling===element) {
            if (element.parentElement && sibling.length > 1) {
                var value = {
                    parent: element.parentNode.nodeName.toLowerCase(),
                    child: element.tagName.toLowerCase() + ((ix+1)>1 ? '[' + (ix + 1) + ']' : '')
                };
                //parents.push(value);
            }
            return getPosition(element.parentNode) + "/" + element.tagName.toLowerCase() + ((ix+1)>1 ? '[' + (ix + 1) + ']' : '');
        }    
        if (sibling.nodeType===1 && sibling.tagName === element.tagName) {
            ix++;
        }
    }
}

function xpathHtmlElement (name) {
    if (this.window.document.contentType == 'application/xhtml+xml') {
        // "x:" prefix is required when testing XHTML pages
        return "x:" + name;
    } else {
        return name;
    }
}

function relativeXPathFromParent(current) {
    var index = getNodeNbr(current);
    var currentPath = '/' + xpathHtmlElement(current.nodeName.toLowerCase());
    if (index > 0) {
        currentPath += '[' + (index + 1) + ']';
    }
    return currentPath;
}

function ku_GetPosition(e) {
    //this.log.debug("positionXPath: e=" + e);
    var path = '';
    var current = e;
    while (current != null) {
    alert('inside while');
        var currentPath;
        if (current.parentNode != null) {
            currentPath = relativeXPathFromParent(current);
        } else {
            currentPath = '/' + xpathHtmlElement(current.nodeName.toLowerCase());
        }
        path = currentPath + path;
        var locator = '/' + path;   
        if (e == findElement(locator)) {
            return locator;
        }     
        
        current = current.parentNode;
        //this.log.debug("positionXPath: current=" + current);
    }
    return null;
}

function getNodeNbr(current) {
    var childNodes = current.parentNode.childNodes;
    var total = 0;
    var index = -1;
    for (var i = 0; i < childNodes.length; i++) {
        var child = childNodes[i];
        if (child.nodeName == current.nodeName) {
            if (child == current) {
                index = total;
            }
            total++;
        }
    }
    return index;
}

function pageBot() {
    var pageBot = this.window._locator_pageBot;
    if (pageBot == null) {
        //pageBot = BrowserBot.createForWindow(this.window);
        pageBot = new MozillaBrowserBot(this.window);
        var self = this;
        pageBot.getCurrentWindow = function() {
            return self.window;
        };
        this.window._locator_pageBot = pageBot;
    }
    return pageBot;
}

function findElement(locator) {
    try {
        return pageBot().findElement(locator);
    } catch (error) {
        //this.log.debug("findElement failed: " + error + ", locator=" + locator);
        return null;
    }
}

function createXPathFromElement(element) {
    var allNodes = document.getElementsByTagName('*');
    for (var segs = []; element && element.nodeType == 1; element = element.parentNode) {
        if ((element.getAttribute('id') != null) && (element.getAttribute('id') !== '')) {
            var uniqueIdCount = 0;
            for (var n = 0; n < allNodes.length; n++) {
                if (((allNodes[n].getAttribute('id') != null) || (allNodes[n].getAttribute('id') !== ''))
                        && allNodes[n].id == element.id)
                    uniqueIdCount++;
                if (uniqueIdCount > 1)
                    break;
            }
            
            if (uniqueIdCount == 1) {
                segs.unshift('id("' + element.getAttribute('id') + '")');
                return segs.join('/');
            }
            if (element.nodeName) {
                segs.unshift(element.nodeName.toLowerCase() + '[@id="' + element.getAttribute('id') + '"]');
            }
        } else if ((element.getAttribute('class') != null) && (element.getAttribute('class') !== '')) {
            segs.unshift(element.nodeName.toLowerCase() + '[@class="' + element.getAttribute('class').trim() + '"]');
        } else {
            for (i = 1, sib = element.previousSibling; sib; sib = sib.previousSibling) {
                if (sib.nodeName == element.nodeName)
                    i++;
            }
            segs.unshift(element.nodeName.toLowerCase() + '[' + i + ']');
        }
        
    }
    
    return segs.length ? '/' + segs.join('/') : null;
}

function relativeXPathFromParent(current) {
    var index = getNodeNbr(current);
    var currentPath = '/' + xpathHtmlElement(current.nodeName.toLowerCase());
    if (index > 0) {
        currentPath += '[' + (index + 1) + ']';
    }
    return currentPath;
   }

 function attributeValue(value) {
    if (value.indexOf("'") < 0) {
        return "'" + value + "'";
    } else if (value.indexOf('"') < 0) {
        return '"' + value + '"';
    } else {
        var result = 'concat(';
        var part = "";
        while (true) {
            var apos = value.indexOf("'");
            var quot = value.indexOf('"');
            if (apos < 0) {
                result += "'" + value + "'";
                break;
            } else if (quot < 0) {
                result += '"' + value + '"';
                break;
            } else if (quot < apos) {
                part = value.substring(0, apos);
                result += "'" + part + "'";
                value = value.substring(part.length);
            } else {
                part = value.substring(0, quot);
                result += '"' + part + '"';
                value = value.substring(part.length);
            }
            result += ',';
        }
        result += ')';
        return result;
    }
}

function xpathHtmlElement(name) {
    if (this.window.document.contentType == 'application/xhtml+xml') {
        // "x:" prefix is required when testing XHTML pages
        return "x:" + name;
    } else {
        return name;
    }
}

function idRelative(e) {
    var path = '';
    var current = e;
    var newLocator='';
    while (current != null) {
        if (current.parentNode != null) {
            path = relativeXPathFromParent(current) + path;
            if (1 == current.parentNode.nodeType && current.parentNode.getAttribute("id")) {
                return  preciseXPath("//" + xpathHtmlElement(current.parentNode.nodeName.toLowerCase()) + "[@id=" + attributeValue(current.parentNode.getAttribute('id')) + "]" +path, e);
            }
        } else {
            return null;
        }
        current = current.parentNode;
    }
    return newLocator;
}

function getNodeNbr(current) {
    var childNodes = current.parentNode.childNodes;
    var total = 0;
    var index = -1;
    for (var i = 0; i < childNodes.length; i++) {
        var child = childNodes[i];
        if (child.nodeName == current.nodeName) {
            if (child == current) {
                index = total;
            }
            total++;
        }
    }
    return index;
}

 function preciseXPath(xpath, e) {
    //only create more precise xpath if needed
        var result = e.ownerDocument.evaluate(xpath, e.ownerDocument, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        
        //skip first element (result:0 xpath index:1)
        for (var i = 0, len = result.snapshotLength; i < len; i++) {
            var newPath = '(' + xpath + ')[' + (i + 1) + ']';
                return newPath;
        }
    
}

function attributesXPath(name, attNames, attributes,e) {
        var locator = "//" + xpathHtmlElement(name) + "[";
        for (i = 0; i < attNames.length; i++) {
            if (i > 0) {
                locator += " and ";
            }
            var attName = attNames[i];
            locator += '@' + attName + "=" + attributeValue(attributes[attName]);
        }
        locator += "]";
        return preciseXPath(locator, e);
    }
    
function xpathByAttributes(e) {
    const PREFERRED_ATTRIBUTES = ['id', 'name', 'value', 'type', 'action', 'onclick'];
    var i = 0;

    if (e.attributes) {
        var atts = e.attributes;
        var attsMap = {};
        for (i = 0; i < atts.length; i++) {
            var att = atts[i];
            attsMap[att.name] = att.value;
        }
        var names = [];
        // try preferred attributes
        for (i = 0; i < PREFERRED_ATTRIBUTES.length; i++) {
            var name = PREFERRED_ATTRIBUTES[i];
            if (attsMap[name] != null) {
                names.push(name);
                var locator = attributesXPath(e.nodeName.toLowerCase(), names, attsMap,e);
                //if (e == this.findElement(locator)) {
                    return locator;
               // }
            }
        }
    }
    return null;
}

function xpathByLink(e) {
    if (e.nodeName == 'A') {
        var text = e.textContent;
        if (!text.match(/^\s*$/)) {
            return preciseXPath("//" + xpathHtmlElement("a") + "[contains(text(),'" + text.replace(/^\s+/, '').replace(/\s+$/, '') + "')]", e);
        }
    }
    return null;
}

 function getCSSSubPath(e) {
    var css_attributes = ['id', 'name', 'class', 'type', 'alt', 'title', 'value'];
    for (var i = 0; i < css_attributes.length; i++) {
        var attr = css_attributes[i];
        var value = e.getAttribute(attr);
        if (value) {
            if (attr == 'id')
                return '#' + value;
            if (attr == 'class')
                return e.nodeName.toLowerCase() + '.' + value.replace(/\s+/g, ".").replace("..", ".");
            return e.nodeName.toLowerCase() + '[' + attr + '="' + value + '"]';
        }
    }
    if (getNodeNbr(e))
        return e.nodeName.toLowerCase() + ':nth-of-type(' + getNodeNbr(e) + ')';
    else
        return e.nodeName.toLowerCase();
}

function getCSSLocator(e) {
    var current = e;
    var sub_path = getCSSSubPath(e);
    while (current.nodeName.toLowerCase() != 'html') {
        sub_path = getCSSSubPath(current.parentNode) + ' > ' + sub_path;
        current = current.parentNode;
    }
    return "css=" + sub_path;
}