package com.autoheal.testsuites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

import com.autoheal.base.BaseTestClass;
import com.autoheal.pages.RegistrationPage;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;

public class SampleTestPOC_Final extends BaseTestClass {
	
	
	@Test
	public void registrationTest() throws InterruptedException, FilloException, IOException{	
		
		RegistrationPage registrationPage = new RegistrationPage(eventDriver);
		registrationPage.invoke("registration.html");
		registrationPage.sendKeys(registrationPage.textBoxFirstName, "First Name - AUTOMATION");
		registrationPage.sendKeys(registrationPage.textBoxLastName, "Last Name - WELLSFARGO");
		registrationPage.sendKeys(registrationPage.textBoxEmailID,"SampleEmailID@Email.com");
		registrationPage.sendKeys(registrationPage.textBoxPhone,"9876543210");
		registrationPage.sendKeys(registrationPage.textBoxComments,"Comments into Text Box");
		registrationPage.click(registrationPage.buttonSubmit);
		System.out.println("END OF TEST SCRIPT");
		Thread.sleep(5000);
	}
	
	@Test
	public void registrationAutoHealTest() throws InterruptedException, FilloException, IOException{	
		
		RegistrationPage registrationPage = new RegistrationPage(eventDriver);
		registrationPage.invoke("registrationnew.html");
		registrationPage.sendKeys(registrationPage.textBoxFirstName, "First Name - AUTOMATION");
		registrationPage.sendKeys(registrationPage.textBoxLastName, "Last Name - WELLSFARGO");
		registrationPage.sendKeys(registrationPage.textBoxEmailID,"SampleEmailID@Email.com");
		registrationPage.sendKeys(registrationPage.textBoxPhone,"9876543210");
		registrationPage.sendKeys(registrationPage.textBoxComments,"Comments into Text Box");
		registrationPage.click(registrationPage.buttonSubmit);
		System.out.println("END OF TEST SCRIPT");
		Thread.sleep(5000);
	}
	
	public static void getClassnPackageName() {
		pageClassName = "";
		packageName = "";
		String[] pageClassNameTemp = stack[1].toString().split("<init>")[0].split("[.]");		
		pageClassName = pageClassNameTemp[pageClassNameTemp.length-1];
		System.out.println(pageClassName);	
		for (int i = 0; i <= (pageClassNameTemp.length - 2); i++) {
			if(i==(pageClassNameTemp.length - 2)) {
				packageName = packageName+pageClassNameTemp[i];
			}else {
				packageName = packageName+pageClassNameTemp[i]+".";
			}
		}
		System.out.println(packageName);
	}
	
	public static void deleteRow() throws IOException {
		FileInputStream file = new FileInputStream(new File(System.getProperty("user.dir")+"\\Resources\\AlternateLocators.xlsx")); 
		XSSFWorkbook workbook = new XSSFWorkbook(file); 
		XSSFSheet sheet = workbook.getSheetAt(0);
		
		int rownum = sheet.getLastRowNum() + 1;
        for(int i = 1; i<=rownum; i++)
        {	
        	try {
        	sheet.shiftRows(i, sheet.getLastRowNum(), -1);
        	rownum = sheet.getLastRowNum() + 1;
        	}catch (Exception e) {
        		System.out.println(e.getMessage());
        	}
        	
        }
        
        FileOutputStream out = new FileOutputStream(new File(System.getProperty("user.dir")+"\\Resources\\AlternateLocators.xlsx")); 
        workbook.write(out); 
        out.close(); 
       
        
	}
	
}
