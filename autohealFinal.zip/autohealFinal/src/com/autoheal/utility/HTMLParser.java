package com.autoheal.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.autoheal.base.BaseTestClass;
import com.codoid.products.fillo.RegEX;


public class HTMLParser {
	public static String src = "";
	public static String url = "";
	public static String str = "";	

	public static HashMap<String, String> parseHTML(String str, String url) {
		Document doc;
		JSONObject json = new JSONObject();
		try {
			BaseTestClass.attributes.clear();
			//doc = Jsoup.parse(new File(System.getProperty("user.dir")+"\\Resources\\"+BaseTestClass.pageClassName+".txt"),"UTF-8");
			doc = Jsoup.parse(BaseTestClass.webDriver.getPageSource());
			//			str="label[text()='Password']";
			Elements body = doc.select(str);

			if(body.is(str)) { 
				//System.out.println("Evalutation true");
				//System.out.println(body.first().attributes());
				Attributes attr=body.first().attributes();
				//System.out.println("List : "+attr.asList());
				//System.out.println("attribute Key value: "+attr.get("id"));
				//BaseTestClass.attributes.put("tagname",body.toString().split("<")[1].split(" ")[0].toString());
				WebElement el=BaseTestClass.webDriver.findElement(By.xpath(BaseTestClass.elementXpath));

				if(body.first().tagName().equals("input"))
				{
					try
					{
						if(getXpath(doc,el).size()>0)
						{
							BaseTestClass.attributes.put("xpath:label-1", getXpath(doc,el).get(0));
							BaseTestClass.attributes.put("xpath:label-2", getXpath(doc,el).get(1));
						}
					}
					catch(Exception e)
					{
						System.out.println("Exception in getXpath()");
					}
					//BaseTestClass.attributes.put("xpath:dynamic", createXPathFromElement( el, BaseTestClass.webDriver));
				}
				BaseTestClass.attributes.put("xpath:position", getPosition(doc, el, BaseTestClass.webDriver));
				BaseTestClass.attributes.put("xpath:idRelative", idRelative(el, BaseTestClass.webDriver));
				//System.out.println("Create:"+createXPathFromElement(el,BaseTestClass.webDriver));
			}
		}catch (Exception e) {
			System.out.println("Failed in - parseHTML");
		}
		//System.out.println(BaseTestClass.attributes.toString());
		return BaseTestClass.attributes;		
	}

	public static ArrayList<String> getXpath(Document doc, WebElement element) {
		ArrayList<String> locators = new ArrayList<String>();
		Elements e = doc.select(converXpathToCss(element));
		if(!e.prev().isEmpty())
		{
			if(e.prev().toString().startsWith("<label")) {
				String loc1 = "//label[text()='"+e.prev().text()+"']/following-sibling::input";
				locators.add(loc1);
				//System.out.println(loc1);
				String attrFor = e.prev().attr("for");
				if (!attrFor.isEmpty()) {
					String loc2 = "//label[@for='"+attrFor+"']/following-sibling::input";
					//System.out.println(loc2);
					locators.add(loc2);
				}
			}
		}else {
			System.out.println("Label not found");
		}
		return locators;
	}

	public static String converXpathToCss(WebElement element) {
		String str1=element.toString().split("->")[1].replace(":","=").trim();
		String str = str1;
		str = str.replace("@", "").replace("//", " ").replace("\"", "'").replaceAll("xpath\\s*=\\s*", "").replace("]]", "]");
		//System.out.println(str);
		return str;
	}
	public static String getPosition(Document doc, WebElement element, WebDriver driver) {
		String javaScript = readJavaScriptFile();
		//String fileContents = Files.toString(new File("resources\\javaScript\\getPosition.js"), Charsets.UTF_8);
		JavascriptExecutor js =(JavascriptExecutor)driver;
		Object locator = js.executeScript(javaScript + "\r\n return getPosition(arguments[0]) ", element);

		System.out.println(locator.toString());

		return locator.toString();
	}

	public static String createXPathFromElement(WebElement element, WebDriver driver) {
		System.out.println("Param inside function CreateXpathfromElement = " + element);
		String javaScript = readJavaScriptFile();
		//String fileContents = Files.toString(new File("resources\\javaScript\\getPosition.js"), Charsets.UTF_8);
		JavascriptExecutor js =(JavascriptExecutor)driver;
		Object locator = js.executeScript(javaScript + "\r\n return createXPathFromElement(arguments[0]) ", element);
		System.out.println(locator.toString());
		return null;

	}
	public static String readJavaScriptFile() {
		try {
			File file = new File(System.getProperty("user.dir")+"\\Resources\\Input\\locator.js");
			return FileUtils.readFileToString(file, StandardCharsets.UTF_8);
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}
		return null;
	}

	public static String idRelative(WebElement element, WebDriver driver) {
		String javaScript = readJavaScriptFile();
		JavascriptExecutor js =(JavascriptExecutor)driver;
		Object locator = js.executeScript(javaScript + "\r\n return idRelative(arguments[0]); ", element);
		
		return locator.toString();

	}

}
