package com.autoheal.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.autoheal.base.BaseTestClass;


public class ExcelUtil {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//Map<String,Map<String, String>> collection = new HashMap<String,Map<String,String>>();
		Map<String, String> hashmap= new HashMap<String,String>();
		hashmap.put("PageName","LoginPage");
		hashmap.put("ObjectName","UserName");
		hashmap.put("CurrentXpath", "//input[@id='un']");
		Map<String, String> hashmap1= new HashMap<String,String>();
		hashmap1.put("xpath:attributes","//input[@id='un']");
		hashmap1.put("xpath:position","//input[1]");
		//hashmap.put("Locators", hashmap1);

		/*Map<String, String> hashmap2= new HashMap<String,String>();
		hashmap2.put("FieldName","Password");
		hashmap2.put("Operation","sendkeys");
		collection.add(hashmap2);*/
		//writeCollection(new File(System.getProperty("user.dir")+"\\Resources\\Data.xlsx"),"Locators",collection);
		//writeCollection(new File(System.getProperty("user.dir")+"\\Resources\\Data.xlsx"),"Locators",hashmap2);
		writeCollection(hashmap, hashmap1);
	}

	public static void readExcelAndEvaluateXpath(String objectName) {
		try {
			FileInputStream file=new FileInputStream(new File(System.getProperty("user.dir")+"\\Resources\\Data.xlsx"));  
			XSSFWorkbook workbook = new XSSFWorkbook(file); 
			XSSFSheet sheet = workbook.getSheetAt(0);//("Locators"); 
			int count = 1;
			boolean testDataOneEntry = false;
			boolean operationOneEntry = false;
			int usedRowNum = sheet.getLastRowNum();
			for(int i = 1; i<=usedRowNum; i++) {
				Row row = sheet.getRow(i);
				int usedColNum = row.getLastCellNum();
				for(int j =0; j<=usedColNum; j++){  
					String pageClass=row.getCell(j).getStringCellValue();
					String elementName=row.getCell(j+4).getStringCellValue();
					System.out.println(BaseTestClass.elementName);
					if (pageClass.contentEquals(BaseTestClass.pageClassName) && elementName.contentEquals(BaseTestClass.elementXpath) && (row.getCell(6)!= null)) {
						BaseTestClass.xpaths.put("xpath"+count,row.getCell(6).getStringCellValue());
						count = count+1;
						if (!testDataOneEntry) {
							BaseTestClass.xpaths.put("testdata",row.getCell(2).getStringCellValue());							
							testDataOneEntry = true;
						}
						if (!operationOneEntry) {
							BaseTestClass.xpaths.put("operation", row.getCell(3).getStringCellValue());
							operationOneEntry = true;
						}
						break;
					}else {
						break;
					}
				}
			}
		}catch(Exception e) {
			System.out.println("Failure in method - readExcelAndEvaluateXpath"+e.getMessage());
		}
	}

	public static boolean checkXpathInFile(String pageClassName,String objectXpath) {
		boolean flag=false;
		try {
			FileInputStream file=new FileInputStream(new File(System.getProperty("user.dir")+"\\Resources\\Data.xlsx"));  
			XSSFWorkbook workbook = new XSSFWorkbook(file); 
			XSSFSheet sheet = workbook.getSheetAt(0);//("Locators"); 
			int count = 1;
			boolean testDataOneEntry = false;
			boolean operationOneEntry = false;
			int usedRowNum = sheet.getLastRowNum();
			for(int i = 1; i<=usedRowNum; i++) {
				Row row = sheet.getRow(i);
				String pageClass=row.getCell(0).getStringCellValue();
				String elementName=row.getCell(4).getStringCellValue();
				System.out.println(BaseTestClass.elementName);
				if (pageClass.contentEquals(pageClassName) && elementName.contentEquals(objectXpath) ) {
					flag=true;
					break;
				}
			}
		}catch(Exception e) {
			System.out.println("Failure in method - readExcelAndEvaluateXpath"+e.getMessage());
		}
		return flag;
	}

	public static void writeCollection(File file, String sheetName, List<Map<String, String>> collection) throws Exception {
		try {
			FileInputStream fileInputStream = new FileInputStream(file);
			XSSFWorkbook workBook = new XSSFWorkbook(fileInputStream);
			XSSFSheet sheet = workBook.getSheet("Locator");
			int rows = sheet.getLastRowNum();
			fileInputStream.close();
			rows = rows + 1;

			for (int index = 0; index < collection.size(); index++) {
				XSSFRow row = sheet.createRow(rows++);
				Map<String, String> rowObject = collection.get(index);
				for (String columnName : rowObject.keySet()) {
					int cellIndex = getColumnIndex(sheet, columnName);
					if (cellIndex != -1) {
						XSSFCell cell = row.createCell(cellIndex);
						cell.setCellValue(rowObject.get(columnName));
					}
				}
			}
			FileOutputStream out = new FileOutputStream(file);
			workBook.write(out);
			out.close();

		} catch (Exception e) {
			throw e;
		}
	}

	/*	public static void writeCollection( Map<String, String> collection) throws Exception {
		try {
			File file=new File(System.getProperty("user.dir")+"\\Resources\\Data.xlsx");
			 FileInputStream fileInputStream = new FileInputStream(file); 
			//FileInputStream fileInputStream = new FileInputStream(file);
			XSSFWorkbook workBook = new XSSFWorkbook(fileInputStream);
			XSSFSheet sheet = workBook.getSheet("Locators");
			int rows = sheet.getLastRowNum();
			fileInputStream.close();
			rows = rows + 1;

				XSSFRow row = sheet.createRow(rows++);
				//Map<String, String> rowObject = collection.get(index);
				for (String columnName : collection.keySet()) {
					int cellIndex = getColumnIndex(sheet, columnName);
					if (cellIndex != -1) {
						XSSFCell cell = row.createCell(cellIndex);
						cell.setCellValue(collection.get(columnName));
					}
				}
			FileOutputStream out = new FileOutputStream(file);
			workBook.write(out);
			out.close();

		} catch (Exception e) {
			throw e;
		}
	}*/

	public static void writeCollection( Map<String, String> colHeaders,Map<String, String> axpaths) throws Exception {
		try {
			File file=new File(System.getProperty("user.dir")+"\\Resources\\Data.xlsx");
			FileInputStream fileInputStream = new FileInputStream(file); 
			//FileInputStream fileInputStream = new FileInputStream(file);
			XSSFWorkbook workBook = new XSSFWorkbook(fileInputStream);
			XSSFSheet sheet = workBook.getSheet("TestData");



			//Map<String, String> rowObject = collection.get(index);
			for(String path:axpaths.keySet())
			{
				//System.out.println(BaseTestClass.packageName);
				//System.out.println(BaseTestClass.elementXpath);
				int rows = sheet.getLastRowNum();
				fileInputStream.close();
				rows = rows + 1;
				XSSFRow row = sheet.createRow(rows++);
				for (String columnName : colHeaders.keySet()) 
				{
					if(colHeaders.get(columnName).equals(BaseTestClass.elementXpath))
					{
						int cellIndex = getColumnIndex(sheet, "ObjectName");
						if (cellIndex != -1) {
							XSSFCell cell = row.createCell(cellIndex);
							cell.setCellValue(columnName);
						}

						cellIndex = getColumnIndex(sheet, "CurrentXpath");
						if (cellIndex != -1) {
							XSSFCell cell = row.createCell(cellIndex);
							cell.setCellValue(colHeaders.get(columnName));
						}

					}
				}
				int cellIndex = getColumnIndex(sheet, "PageName");
				if (cellIndex != -1) {
					XSSFCell cell = row.createCell(cellIndex);
					cell.setCellValue(BaseTestClass.pageClassName);
				}
				cellIndex = getColumnIndex(sheet, "AlternateXpathType");
				if (cellIndex != -1) {
					XSSFCell cell = row.createCell(cellIndex);
					cell.setCellValue(path);
				}
				cellIndex = getColumnIndex(sheet, "AlternateXpathValue");
				if (cellIndex != -1) {


					XSSFCell cell = row.createCell(cellIndex);
					cell.setCellValue(axpaths.get(path));
				}
				cellIndex = getColumnIndex(sheet, "TestData");
				if (cellIndex != -1) {


					XSSFCell cell = row.createCell(cellIndex);
					cell.setCellValue(BaseTestClass.testDataAndOperation.get("testdata"));
				}

				cellIndex = getColumnIndex(sheet, "Operation");
				if (cellIndex != -1) {


					XSSFCell cell = row.createCell(cellIndex);
					cell.setCellValue(BaseTestClass.testDataAndOperation.get("operation"));
				}
			}
			FileOutputStream out = new FileOutputStream(file);
			workBook.write(out);
			out.close();

		} catch (Exception e) {
			throw e;
		}
	}


	public static int getColumnIndex(XSSFSheet sheet, String columnName) {
		int columnIndex = -1;
		try {
			int colNum = sheet.getRow(0).getLastCellNum();
			XSSFRow firstRow = sheet.getRow(0);
			for (int colIndex = 0; colIndex < colNum; colIndex++) {
				XSSFCell cell = firstRow.getCell(colIndex);
				if (cell.toString().equals(columnName)) {
					columnIndex = colIndex;
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return columnIndex;
	}
}
