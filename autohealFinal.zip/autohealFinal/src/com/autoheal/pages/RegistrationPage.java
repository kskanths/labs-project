package com.autoheal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.autoheal.base.BasePageClass;
import com.autoheal.base.BaseTestClass;

public class RegistrationPage extends BasePageClass {
	
	
	public RegistrationPage(EventFiringWebDriver eventDrive) {
		super(eventDrive);
		BaseTestClass.stack = Thread.currentThread().getStackTrace();
		findWebElementName(this);	
		WebElement el = driver.findElement(By.xpath("/html"));
		BaseTestClass.sourceCode=el.getAttribute("innerHTML");
	}
	

	@FindBy(how = How.XPATH,using="//input[@id='firstname']")
	public WebElement textBoxFirstName;
	
	@FindBy(how = How.XPATH,using="//input[@id='lastname']")
	public WebElement textBoxLastName;
	
	@FindBy(how = How.XPATH,using="//input[@id='phone']")
	public WebElement textBoxPhone;
	
	@FindBy(how = How.XPATH,using="//input[@id='email']")
	public WebElement textBoxEmailID;
	
	@FindBy(how = How.XPATH,using="//textarea[@id='comment']")
	public WebElement textBoxComments;
	
	@FindBy(how = How.XPATH,using="//input[@id='submit']")
	public WebElement buttonSubmit;
	
	public void invoke(String url) {
		driver.get(System.getProperty("user.dir")+"/Resources/Input/"+url);
		
	}
}
