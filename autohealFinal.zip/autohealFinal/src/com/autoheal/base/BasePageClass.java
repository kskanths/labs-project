package com.autoheal.base;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.Reporter;

public class BasePageClass {
	protected EventFiringWebDriver driver;
	
	public BasePageClass(EventFiringWebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	public void sendKeys(WebElement we, String data) {
		try {
			BaseTestClass.testDataAndOperation.put("testdata",data);
			BaseTestClass.testDataAndOperation.put("operation","sendKeys");
			we.sendKeys(data);
			Reporter.log("Performed sendkeys operation on "+we+" element", true);
			
		}catch(Exception e) {
			System.out.println("FAILURE IN - sendKeys"+e.getMessage());
		}
	}
	public void click(WebElement we) {
		try {
			BaseTestClass.testDataAndOperation.put("testdata","");
			BaseTestClass.testDataAndOperation.put("operation","click");
			we.click();
			Reporter.log("Performed click operation on "+we +" element", true);
			
		}catch(Exception e) {
			System.out.println("FAILURE IN - sendKeys"+e.getMessage());
		}
	}
	
	public void switchToWindow() {
		String hndl = driver.getWindowHandle();
		
		Set<String> hndls = driver.getWindowHandles();
		for (String h: hndls) {
			if(!hndl.equals(h)) {
				driver.switchTo().window(h);
			}
		}
		
	}
	
	
	
	public static void findWebElementName(Object object) {
		try {
			Class<?> validationClass = object.getClass();
			Field[] field = validationClass.getFields();
			for (Field f: field) {
				f.setAccessible(true);
				if(f.getType() ==  WebElement.class && f.isAnnotationPresent(FindBy.class)){
					FindBy findBy = f.getAnnotation(FindBy.class);
					if (!(findBy.using().toString()=="")) {
						try {
	                    	BaseTestClass.elementName = f.getName();
	                    	BaseTestClass.headers.put("ObjectName", f.getName());
	                    	//BaseTestClass.elementsAndTheirXpaths.put(BaseTestClass.elementName,findBy.using().toString().trim());
	                    	BaseTestClass.headers.put(BaseTestClass.elementName,findBy.using().toString().trim());
	                    	System.out.println("Element Name = "+BaseTestClass.elementName);
	                    }catch(Exception e) {
	                    	System.out.println(e.getMessage());
	                    }
				}
			}	
		}
			} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void writeHTMLFile() throws IOException {
		try {
		File file = new File(System.getProperty("user.dir")+"\\Resources\\"+BaseTestClass.pageClassName+".html");
		/*FileOutputStream fos = new FileOutputStream(fout);
		BufferedReader bufferedReader = new BufferedReader(BaseTestClass.sourceCode);
		BufferedWriter writer = new BufferedWriter(new FileWriter( yourfilename(fout))*/
		
		//File newTextFile = new File("C:/thetextfile.txt");
		if (!file.exists()) {
			file.createNewFile();
		}
        FileWriter filewriter = new FileWriter(file);
        filewriter.write(BaseTestClass.sourceCode);
        filewriter.close();
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void writeTXTFile() throws IOException {
		try {
		File file = new File(System.getProperty("user.dir")+"\\Resources\\"+BaseTestClass.pageClassName+".txt");
		/*FileOutputStream fos = new FileOutputStream(fout);
		BufferedReader bufferedReader = new BufferedReader(BaseTestClass.sourceCode);
		BufferedWriter writer = new BufferedWriter(new FileWriter( yourfilename(fout))*/
		
		//File newTextFile = new File("C:/thetextfile.txt");
		if (!file.exists()) {
			file.createNewFile();
		}
        FileWriter filewriter = new FileWriter(file);
        filewriter.write(BaseTestClass.sourceCode);
        filewriter.close();
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
