package com.autoheal.base;



import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.autoheal.listener.CustomWebDriverListener;



public class BaseTestClass {
	public static StackTraceElement[] stack ;
	public static String byString = "";
	public static WebDriver webDriver;
	public static EventFiringWebDriver eventDriver;
	public static String testClassName = "";
	public static String pageClassName = "";
	public static String packageName = "";
	public static String elementName = "";
	public static String elementXpath = "";
	public static String testData = "";
	public static HashMap<String,String> headers = new HashMap<String,String>();
	public static HashMap<String,String> attributes = new HashMap<String,String>();
	public static HashMap<String, String> elementsAndTheirXpaths = new HashMap<String,String>();
	public static HashMap<String, String> xpaths = new HashMap<String,String>();
	public static HashMap<String,String> testDataAndOperation = new HashMap<String,String>();
	public static String sourceCode = "";
	public static Properties props;
	public static String currentObject="";
	
	@BeforeMethod
	public void beforeMethod() {
		try {
			this.readApplicationProperties();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Server\\chromedriver.exe");
		webDriver = new ChromeDriver();
		eventDriver = new EventFiringWebDriver(webDriver);
		CustomWebDriverListener handler = new CustomWebDriverListener();
		eventDriver.register(handler);
		eventDriver.manage().window().maximize();
		//eventDriver.get("https://google.com");
		//eventDriver.get("http://webdriveruniversity.com/index.html");
		//eventDriver.get("https://www.classmarker.com/");
		//eventDriver.get(System.getProperty("user.dir")+"/Resources/Input/registrationnew.html");
	}
	
	@AfterMethod
	public void afterMethod() {
		eventDriver.quit();
	}
	
	public void readApplicationProperties() throws IOException {
		FileReader reader=new FileReader(System.getProperty("user.dir")+"\\Resources\\Config\\application.properties");
		props=new Properties();
		props.load(reader);
	}
}
