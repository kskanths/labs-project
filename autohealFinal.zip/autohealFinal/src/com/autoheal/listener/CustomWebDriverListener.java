package com.autoheal.listener;

import java.io.IOException;
import java.lang.StackWalker.StackFrame;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;
import org.testng.Reporter;

import com.autoheal.base.BasePageClass;
import com.autoheal.base.BaseTestClass;
import com.autoheal.testsuites.SampleTestPOC_Final;
import com.autoheal.utility.ExcelUtil;
import com.autoheal.utility.HTMLParser;


public class CustomWebDriverListener implements WebDriverEventListener{

	private By lastFindBy;
	private WebElement lastElement;
	private String originalValue;
	private String pageName;
	
	public void beforeAlertAccept(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterAlertAccept(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterAlertDismiss(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void beforeAlertDismiss(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void beforeNavigateTo(String url, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterNavigateTo(String url, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void beforeNavigateBack(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterNavigateBack(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void beforeNavigateForward(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterNavigateForward(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void beforeNavigateRefresh(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterNavigateRefresh(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}
	
	public void beforeFindBy(By by, WebElement element, WebDriver driver) {
		// TODO Auto-generated method stub
		String currentElement="";
		try {
			BaseTestClass.elementXpath = "";
			BaseTestClass.elementXpath = by.toString().split(":")[1].trim();
			currentElement=by.toString().split(":")[1].trim();
			//driver.findElement(By.xpath(BaseTestClass.elementXpath)).isDisplayed();	
			int size=driver.findElements(By.xpath(BaseTestClass.elementXpath)).size();
			/*final List<StackWalker.StackFrame> stack = (List<StackFrame>) StackWalker.getInstance().walk(s -> s.collect(Collectors.toList()));
		      for(StackWalker.StackFrame sf : stack) {
		    	  //if(sf.getMethodName().equals("<init>"))
		         System.out.println(sf.getClassName() + "::" + sf.getMethodName() + ":" + sf.getLineNumber());
		        // System.out.println(sf.getDeclaringClass());
		      }*/
			if(size==0)
			{
				if (BaseTestClass.props.getProperty("Self_Healing_Phase").equals("true")) {
					SampleTestPOC_Final.getClassnPackageName();
					//System.out.println("FAILURE IN LISTENER BEFORE FIND BY - "+e.getMessage());
					ExcelUtil.readExcelAndEvaluateXpath(currentElement);			
					int count = 1;
					String operation = "";
					String testdata = "";
					try {
					for (HashMap.Entry<String, String> entry1 : BaseTestClass.xpaths.entrySet()) {
						if (driver.findElement(By.xpath(BaseTestClass.xpaths.get("xpath"+count))).isDisplayed()) {
							operation = BaseTestClass.xpaths.get("operation");
							if (!(BaseTestClass.xpaths.get("testdata") == null)) {
								testdata = BaseTestClass.xpaths.get("testdata");
							}
							switch (operation){
							case "sendKeys":
								driver.findElement(By.xpath(BaseTestClass.xpaths.get("xpath"+count))).sendKeys("SELF HEALED_"+testdata);
								Reporter.log("<br>Performed sendkeys operation with new locator: '"+BaseTestClass.xpaths.get("xpath"+count)+"' as current locator: '"+BaseTestClass.elementXpath+"'", true);
								break;
							case "click":
								driver.findElement(By.xpath(BaseTestClass.xpaths.get("xpath"+count))).click();
								Reporter.log("<br>Performed click operation with new locator: '"+BaseTestClass.xpaths.get("xpath"+count)+"' as current locator: '"+BaseTestClass.elementXpath+"'", true);
								break;
							default:
								//do nothing
							}
							break;
						}
						count = count + 1;
					}}catch(Exception e1) {
						System.out.println(e1.getMessage());
					}
				}

				
			}
		}catch(Exception e) {
			
			//lastFindBy=By.xpath("//label[text()='Username']/following-sibling::input");
					}
	}

	public void afterFindBy(By by, WebElement element, WebDriver driver) {
		// TODO Auto-generated method stub		
		try {
			if (BaseTestClass.props.getProperty("Learning_Phase").equals("true")) {
				BaseTestClass.elementXpath = "";
				BaseTestClass.elementXpath = by.toString().split(":")[1].trim();
				element.isDisplayed();
				String url = driver.getCurrentUrl();
				String str1=element.toString().split("->")[1].replace(":","=").trim();
				String str = str1;
				str = str.replace("@", "").replace("//", " ").replace("\"", "'").replaceAll("xpath\\s*=\\s*", "").replace("]]", "]");
				//SampleTestPOC_Final.getClassnPackageName();
////				selfHealing.POC.SampleTestPOC_Final.getClassnPackageName();
//				
//				HashMap<String, String> hm = HTMLParser.parseHTML(str, url);
//				ExcelUtility.writeToExcelRowByRow();
				
				if(!BaseTestClass.elementXpath.contentEquals("/html")){
					SampleTestPOC_Final.getClassnPackageName();
					try {
						BasePageClass.writeTXTFile();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					HashMap<String, String> axpaths = HTMLParser.parseHTML(str, url);
					//ExcelUtility.writeToExcelRowByRow();
					//HashMap<String, String> colHeaders=BaseTestClass.
					if(!ExcelUtil.checkXpathInFile(BaseTestClass.pageClassName,BaseTestClass.elementXpath))
					ExcelUtil.writeCollection(BaseTestClass.headers,axpaths);
				}
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());			
		}		
	}

	public void beforeClickOn(WebElement element, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterClickOn(WebElement element, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void beforeChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {
		// TODO Auto-generated method stub
		
	}

	public void afterChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {
		// TODO Auto-generated method stub
	}

	public void beforeScript(String script, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterScript(String script, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void beforeSwitchToWindow(String windowName, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterSwitchToWindow(String windowName, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void onException(Throwable throwable, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public <X> void beforeGetScreenshotAs(OutputType<X> target) {
		// TODO Auto-generated method stub
		
	}

	public <X> void afterGetScreenshotAs(OutputType<X> target, X screenshot) {
		// TODO Auto-generated method stub
		
	}

	public void beforeGetText(WebElement element, WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

	public void afterGetText(WebElement element, WebDriver driver, String text) {
		// TODO Auto-generated method stub
		
	}


}
